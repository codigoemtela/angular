# Aula 3 — Central de Solicitações Internas

Projeto didático da formação Angular do Código em Tela.

## Executar

Use Node 24 compatível com Angular 22 (mínimo 24.15.0 na linha 24).
Na pasta que contém package.json e package-lock.json:

```sh
npm ci
npm start
```

Abra o endereço informado pelo terminal, normalmente http://localhost:4200.
Para encerrar o servidor, use Ctrl+C. Para compilar, execute `npm run build`.
O teste gerado, com o título atualizado, pode ser executado com
`npm test -- --watch=false`.

`npm ci` exige coerência entre package.json e o lock e substitui node_modules.
O projeto usa dados fictícios e estado local. Abrir orientações não altera o
status do pedido. Recarregar reinicia a expansão como oculta.

A pasta projeto-principal preserva o exemplo anterior ao exercício.
A pasta solucao-exercicio acrescenta equipeResponsavel no cabeçalho.

Código original: GPL-3.0-only. Dependências mantêm suas próprias licenças.
Formação: https://youtube.com/@codigoemtela
Organização: https://github.com/codigoemtela
