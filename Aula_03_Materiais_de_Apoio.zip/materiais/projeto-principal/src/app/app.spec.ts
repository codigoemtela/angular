// SPDX-License-Identifier: GPL-3.0-only
import { TestBed } from '@angular/core/testing';
import { App } from './app';

describe('App', () => {
  it('apresenta o nome da Central', async () => {
    await TestBed.configureTestingModule({
      imports: [App]
    }).compileComponents();

    const fixture = TestBed.createComponent(App);
    await fixture.whenStable();
    const elemento = fixture.nativeElement as HTMLElement;

    expect(elemento.querySelector('h1')?.textContent)
      .toContain('Central de Solicitações Internas');
  });
});
