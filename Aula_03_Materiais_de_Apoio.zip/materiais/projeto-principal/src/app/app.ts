// SPDX-License-Identifier: GPL-3.0-only
import { Component, signal } from '@angular/core';

@Component({
  selector: 'cet-root',
  standalone: true,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  readonly titulo = 'Central de Solicitações Internas';
  readonly ambiente = 'Ambiente local de aprendizagem';
  readonly protocolo = 'SOL-1042';
  readonly assunto = 'Não consigo acessar o sistema';
  readonly mostrarOrientacoes = signal(false);

  alternarOrientacoes(): void {
    this.mostrarOrientacoes.update((valor) => !valor);
  }
}
