# Preparando o ambiente e criando o primeiro projeto Angular

Código em Tela | Aula 03 | Roteiro completo para narração e produção

A aula ensina o aluno a preparar as ferramentas, gerar um projeto Angular, executar a aplicação e localizar os arquivos responsáveis pelo que aparece no navegador. A prática cria a base da Central de Solicitações Internas e retoma a relação entre dados, template, estilos e eventos estudada na aula 2. Ao terminar, o aluno deverá conseguir interromper e reiniciar o servidor, fazer uma alteração verificável e explicar como o componente principal chega à tela.

Duração prevista de aproximadamente 54 a 59 minutos, com narração pausada, demonstrações e os cinco blocos de publicação. Os tempos são estimativas de roteiro e serão ajustados depois de gerar a voz. A atividade prática feita pelo aluno fora do vídeo não está incluída nesse tempo.

## Orientações de leitura e produção

As falas com nome de personagem serão narradas. Os parágrafos iniciados por CENA, TELA, DEMONSTRAÇÃO ou PAUSA são orientações de produção, não falas. Os comandos e os arquivos devem aparecer com fonte ampliada e destaque progressivo. A narração explica propósito e resultado; não soletra todo o código. Os apêndices são material de consulta e não entram na duração narrada.

Manter Prof. Rodrigo como professor e Wellington como Scrum Master, usando o visual já aprovado. Helena apresenta a necessidade; Lia, Caio e Marina fazem perguntas técnicas; Bia acompanha a experiência de uso; Rafael confere os resultados. Exibir no máximo três personagens em destaque. As participações acompanham o assunto, sem uma rodada obrigatória de falas. Preservar as vozes em português brasileiro das aulas anteriores.

Reservar margens internas em caixas e balões. O balão resume a pergunta; a legenda contém a fala. Código e terminal ocupam a maior parte do enquadramento durante a demonstração. Não colocar texto sobre rostos, botões importantes ou mensagens de erro. Mostrar primeiro o comportamento quando isso ajudar a explicar a implementação. A solução dos exercícios só aparece depois da pausa.

Cada parte publicada começa com a thumbnail fixa por cinco segundos e termina com seis segundos de tela final. A duração planejada inclui demonstrações e pausas, mas os cortes definitivos dependem da narração e da montagem. Medir cada MP4 e manter todos abaixo de 15 minutos. A atividade fora do vídeo pode levar mais tempo; não alongar artificialmente downloads ou instalações.

## Preparação técnica da demonstração

Usar Angular CLI 22.1.6, a mesma linha do Angular utilizado na aula 2. O Node da conferência local é 24.19.0. Para uma instalação nova, usar a linha 24 LTS compatível com o CLI; a exigência declarada pelo CLI 22.1.6 aceita Node 24 a partir de 24.15.0 e antes de 25. A página de download consultada em 11 de setembro de 2026 oferecia Node 24.21.0 LTS. Conferir novamente os números quando a gravação acontecer. Não apresentar um número fictício como saída do terminal.

O comando de criação registra a versão do gerador. As versões efetivamente resolvidas para a aplicação ficam em package-lock.json e devem ser conferidas com npm ls. Fixar o CLI, sozinho, não congela toda a árvore de dependências gerada. O roteiro usa CSS, componentes standalone, prefixo cet, sem roteamento e sem renderização no servidor nesta etapa. O servidor da aula 3 usa a porta 4200; a porta 4202 do exemplo da aula 2 era uma escolha daquele exemplo.

Na conferência deste roteiro, o gerador 22.1.6 resolveu Angular core 22.1.6, CLI local 22.1.8 e Angular build 22.1.8, com npm 11.9.0. Essa diferença é compatível com os intervalos declarados pelo projeto gerado. Ao mostrar npm ls, usar esses números apenas se forem os da execução filmada.

Fonte técnica: [Compatibilidade do Angular](https://angular.dev/reference/versions) e [Download do Node.js](https://nodejs.org/en/download).

## Divisão editorial prevista

| Parte | Assunto | Seções | Resultado |
| --- | --- | --- | --- |
| 1 | Preparar as ferramentas | 01 a 03 | Node e npm disponíveis e editor preparado |
| 2 | Criar e executar o projeto | 04 a 06 | Aplicação gerada e aberta no navegador |
| 3 | Entender a estrutura | 07 a 09 | Caminho da inicialização identificado e primeira alteração |
| 4 | Construir a base da Central | 10 a 12 | Página com dados locais e botão funcional |
| 5 | Investigar e verificar | 13 a 15 | Exercício resolvido e projeto compilado |

O texto contém 6.347 palavras de fala. A 130 palavras por minuto, somando as pausas marcadas e as aberturas e encerramentos, as partes têm aproximadamente 10min26s, 10min43s, 10min38s, 10min39s e 12min25s. A gravação ainda deve reservar tempo para a leitura progressiva do código e confirmar cada duração real. Manter uma margem confortável em relação ao limite de 15 minutos.

## Parte 1 Preparar as ferramentas

### 01 A equipe precisa executar o projeto

CENA: Thumbnail por cinco segundos. Helena, Rodrigo e Wellington diante do quadro. Mostrar rapidamente o resultado final da aula: título da Central, um protocolo fictício e um botão de orientações. A apresentação do resultado não deve sugerir que o aluno já possui essa aplicação instalada.

HELENA: Na última aula, vimos como uma solicitação aparece em um cartão e como a interface reage às escolhas de quem está usando. Agora preciso que a equipe consiga trabalhar nessa aplicação. Se cada pessoa depender de alguém abrir o exemplo e compartilhar a tela, qualquer alteração vai começar com uma espera.

PROF. RODRIGO: Esse é o ponto de partida da nossa terceira aula. Vamos preparar o ambiente de desenvolvimento, criar um projeto Angular e entender como ele funciona no nosso computador. Depois faremos uma primeira versão da página da Central de Solicitações Internas. Você vai acompanhar a ligação entre um arquivo salvo no editor e uma mudança visível no navegador.

WELLINGTON: Vou registrar no quadro uma atividade de preparação do ambiente. Os critérios são conseguir consultar as versões, gerar o projeto, executar a aplicação e reproduzir uma alteração. Essa atividade apoia o trabalho da sprint. Os cards SOL 01 e SOL 02 continuam representando as necessidades do produto que já discutimos.

PROF. RODRIGO: Na aula anterior, usamos um exemplo pronto para estudar componentes. Hoje vamos construir o caminho que permite executar e modificar um projeto com autonomia. Por isso começaremos com uma aplicação nova e pequena. O cartão completo da aula 2 continua sendo uma referência para evoluir essa base; não precisa ser apagado nem substituído na sua pasta de estudos.

HELENA: E o que vou conseguir ver ao final desta preparação?

PROF. RODRIGO: Uma página com o nome da Central, a identificação de um pedido fictício e um botão que abre orientações. Será um recorte local. Ao recarregar a página, o estado temporário do botão volta ao início. Esse comportamento nos ajuda a distinguir o que estamos escrevendo na interface de informações que, em outra etapa, serão mantidas por um serviço.

WELLINGTON: Para acompanhar, mantenha um lugar para anotar o comando executado e o resultado observado. Se algo falhar, essa anotação ajuda a explicar o problema. A instalação pode levar mais tempo no seu computador. Use a pausa do vídeo quando precisar; a velocidade da demonstração não é uma meta de velocidade para você.

PROF. RODRIGO: Também vamos explicar por que existem várias ferramentas. Você verá o editor, o terminal e o navegador, cada um com uma função. Não precisa chegar sabendo todos os comandos. Vamos ler os que usamos, conferir as respostas e aprender a localizar o próximo passo. Ao final, quero que você consiga repetir o percurso com a sua própria explicação.

PAUSA 8: Mostrar os quatro resultados esperados. Dar tempo para leitura antes de mudar de enquadramento.

### 02 Node npm e a instalação

CENA: Rodrigo, Lia e Marina. Alternar entre o site oficial do Node e o terminal. Na edição, identificar claramente o sistema operacional mostrado. A demonstração principal apresenta o instalador do Windows; o caminho do Linux aparece em seguida, sem exigir que o aluno execute os dois.

LIA: Se o Angular vai aparecer no navegador, por que estamos começando pela instalação do Node? Eu pensei que JavaScript já funcionasse no navegador sem instalar nada.

PROF. RODRIGO: JavaScript pode executar no navegador. O Node permite executar JavaScript também fora dele. Na nossa preparação, ele executa as ferramentas que criam, compilam e servem o projeto durante o desenvolvimento. Isso não significa que cada pessoa que visitar a Central terá que instalar Node. Estamos organizando o computador de quem vai desenvolver a aplicação.

MARINA: O npm acompanha as instalações usuais do Node e administra pacotes. Os pacotes incluem o Angular e ferramentas usadas pelo projeto. Quando você vê uma instalação de dependências, é esse conjunto de bibliotecas e utilitários sendo preparado. Mais adiante vamos identificar onde o projeto declara o que precisa e onde registra as versões instaladas.

PROF. RODRIGO: Abra o site oficial do Node e procure a linha LTS compatível com a versão do Angular da aula. Vamos usar a linha vinte e quatro. LTS identifica uma linha com suporte de longo prazo. A tabela de compatibilidade do Angular informa os intervalos aceitos. Não basta escolher um número maior sem conferir: duas ferramentas podem ter calendários de versão diferentes.

LIA: Então, se o site mostrar um número de correção diferente do seu, isso não quer dizer automaticamente que eu baixei errado?

PROF. RODRIGO: Exatamente. Veja a linha principal, a versão mínima exigida e o intervalo suportado. Para o CLI usado aqui, dentro da linha vinte e quatro precisamos de pelo menos vinte e quatro ponto quinze. Registre o número que realmente apareceu no seu computador. Ao pedir ajuda, informar esse número é mais útil do que dizer apenas que instalou o mais novo.

TELA: No Windows, selecionar o instalador MSI correspondente à arquitetura do computador, abrir o instalador, ler e aceitar os termos se concordar, manter Node, npm e inclusão no PATH, concluir e abrir um novo terminal. Não selecionar ferramentas nativas extras apenas para esta aula. No macOS, usar o instalador oficial compatível e conferir em um terminal novo. Não simular que instalações em sistemas diferentes foram executadas nesta revisão do roteiro.

PROF. RODRIGO: No Windows, baixe o instalador correspondente ao seu computador. Durante a instalação, mantenha os componentes do Node, do npm e a opção que permite encontrá-los pelo terminal. Depois de concluir, feche o terminal antigo e abra outro. O terminal que já estava aberto pode continuar com as informações de ambiente anteriores à instalação.

MARINA: No Linux, siga o caminho indicado para seu sistema no site oficial e confirme que o resultado pertence à linha compatível. Para demonstrar uma alternativa sem trocar os pacotes da distribuição, também podemos usar o arquivo binário oficial extraído dentro da pasta pessoal. Nesse caso, precisamos informar ao terminal onde está a pasta bin desse Node.

PROF. RODRIGO: O apêndice traz os passos dessa alternativa para Bash e fish. Execute somente o caminho correspondente ao seu ambiente. O nome da pasta muda conforme a versão e a arquitetura baixadas. Depois da instalação, todos os caminhos chegam à mesma conferência: perguntar ao Node e ao npm quais versões estão disponíveis. É essa resposta que nos permite seguir.

DEMONSTRAÇÃO 35: Mostrar a seleção do instalador, um corte identificado como instalação concluída e a abertura de um terminal novo. Na alternativa Linux, mostrar a pasta extraída e a localização de bin. Não preencher a duração com barras de progresso.

Fonte técnica: [Ambiente local do Angular](https://angular.dev/tools/cli/setup-local) e [Download do Node.js](https://nodejs.org/en/download).

### 03 Preparar o editor e reconhecer as janelas

CENA: Rodrigo, Bia e Caio. Abrir o VS Code e depois um navegador atualizado. Mostrar o menu de terminal integrado. As telas devem ser reais na gravação sempre que possível.

CAIO: Eu já tenho um editor instalado. Preciso trocar para acompanhar os nomes dos arquivos e os comandos?

PROF. RODRIGO: Vou demonstrar no Visual Studio Code para mantermos uma referência comum. O projeto Angular não depende de uma edição específica desse editor. Você pode acompanhar em outro que permita editar os arquivos e abrir um terminal. Se estiver começando, usar o mesmo ambiente da demonstração facilita localizar os menus enquanto aprende o restante.

BIA: Antes de escrever, vale ajustar o tamanho da fonte. Terminal pequeno e muitas janelas abertas dificultam perceber uma mensagem. Para quem acompanha o vídeo, também precisamos ampliar o trecho importante e deixar o restante em segundo plano. A organização da tela faz parte da explicação.

PROF. RODRIGO: Instale o VS Code pelo site oficial, usando o pacote indicado para seu sistema. No Windows há instalador; no Linux o site distingue os formatos e as distribuições. Abra o editor e localize o menu Terminal, depois Novo Terminal. Esse terminal executa os mesmos tipos de comando que uma janela separada. Estar dentro do editor não muda a função do Node.

CAIO: E aquelas extensões que aparecem nas recomendações? Tenho que instalar uma lista inteira antes de criar o projeto?

PROF. RODRIGO: Para esta aula, vamos conferir a extensão Angular Language Service, mantida pela equipe Angular. Ela ajuda o editor a compreender os templates e apresentar diagnósticos e sugestões. O projeto deve funcionar mesmo sem ela. A extensão melhora a experiência de edição; a compilação continua sendo feita pelas ferramentas do projeto.

BIA: Vou deixar o navegador ao lado para acompanhar o resultado. Quando abrirmos a aplicação, observaremos textos, foco do teclado e o que acontece ao apertar um botão. O editor mostra o que escrevemos; o navegador permite conferir o que uma pessoa realmente recebe na interface.

PROF. RODRIGO: Guarde essa distinção entre três lugares. No editor, modificamos arquivos. No terminal, executamos comandos e lemos respostas. No navegador, usamos a aplicação. Se aparecer uma mensagem, primeiro identifique de qual lugar ela veio. Uma sugestão de extensão no editor e um erro de compilação no terminal podem parecer próximos na tela, mas pedem verificações diferentes.

PAUSA 10: Perguntar onde editar um título, onde consultar a versão do Node e onde conferir o título exibido. Mostrar as respostas somente depois da pausa.

PROF. RODRIGO: Temos as ferramentas identificadas. Na próxima parte vamos conferir a instalação, criar a pasta do projeto e abrir a aplicação pela primeira vez. Se o download ainda está acontecendo no seu computador, conclua essa etapa antes de avançar.

Fonte técnica: [Configuração do VS Code](https://code.visualstudio.com/docs/setup/setup-overview) e [Angular Language Service](https://angular.dev/tools/language-service).

## Parte 2 Criar e executar o projeto

### 04 Conferir as versões e escolher a pasta

CENA: Thumbnail por cinco segundos. Rodrigo, Lia e Rafael. Abrir um terminal novo. Mostrar cada comando sozinho, seguido da saída real. Nunca digitar o símbolo de prompt junto com o comando.

PROF. RODRIGO: Na primeira parte, preparamos as ferramentas. Agora vamos verificar se o terminal consegue encontrá-las. Começaremos com dois comandos curtos. O primeiro consulta a versão do Node. O segundo consulta a versão do npm. Eles não criam um projeto e não instalam pacotes; apenas mostram informações do que está disponível.

```shell
node --version
npm --version
```

LIA: Apareceu um número em cada linha. Eles precisam ser iguais?

PROF. RODRIGO: Não. Node e npm têm versões próprias. O número vinte e quatro que estamos acompanhando pertence ao Node. O npm pode mostrar outro número principal. Registre os dois. Se o comando não for reconhecido, volte à instalação e abra um terminal novo antes de tentar criar o projeto. Não adianta pedir ao npm para trabalhar enquanto o terminal ainda não consegue encontrá-lo.

RAFAEL: No Windows, se o PowerShell indicar especificamente um bloqueio ao script npm ponto ps1, podemos executar npm ponto cmd para essa conferência ou abrir o Prompt de Comando no terminal do editor. Primeiro lemos qual foi o erro. Não precisamos tratar toda mensagem como uma instalação estragada.

PROF. RODRIGO: Agora escolha uma pasta de estudos em que você tenha permissão para criar arquivos. Abra essa pasta no editor. No menu de arquivos, confira o caminho mostrado. Vamos criar dentro dela uma pasta chamada codigoemtela e entrar nessa pasta. Se ela já existir, apenas entre nela; não é necessário apagar seu trabalho para repetir a demonstração.

```shell
mkdir codigoemtela
cd codigoemtela
```

LIA: O cd muda os arquivos ou só muda onde o terminal está trabalhando?

PROF. RODRIGO: Ele muda a pasta atual daquele terminal. Essa localização define onde muitos comandos vão procurar ou criar arquivos. Daqui a pouco, o gerador criará central traço solicitacoes dentro de codigoemtela. Depois precisaremos entrar no projeto para executar seus comandos. Um erro comum é continuar na pasta de cima e perguntar por que o npm não encontrou o arquivo do projeto.

RAFAEL: Para conferir a localização, use pwd no Bash ou no fish. No PowerShell, Get-Location mostra o caminho; no Prompt de Comando, cd sem argumento mostra a pasta atual. São maneiras de responder à mesma pergunta em terminais diferentes. Escolha a correspondente à janela que você está usando.

PROF. RODRIGO: Antes de seguir, confira três resultados: Node respondeu, npm respondeu e estamos na pasta de estudos. O nome exato da sua pasta pessoal pode ser diferente do meu. O que precisa estar claro é onde a nova aplicação será criada e como você vai reencontrá-la depois.

PAUSA 12: Manter na tela os dois comandos de versão e a localização esperada da pasta de estudos. Não exibir caminhos pessoais do usuário ou arquivos de outras atividades.

### 05 O gerador cria a aplicação

CENA: Rodrigo, Marina e Caio. Mostrar o comando de criação em faixa ampla, com uma opção destacada por vez. O comando completo é uma única linha; a quebra visual automática não representa novos comandos.

PROF. RODRIGO: Vamos usar o Angular CLI. CLI é a interface de linha de comando do Angular. Ela automatiza tarefas como gerar o projeto e executar a compilação. Para chamar a versão desta aula, usaremos npx com o pacote arroba angular barra cli, seguido do número vinte e dois ponto um ponto seis. Esse número identifica o gerador que estamos pedindo ao npm.

```shell
npx @angular/cli@22.1.6 new central-solicitacoes --style=css --routing=false --ssr=false --prefix=cet --skip-git --defaults
```

MARINA: O npx permite executar o comando de um pacote. Se o pacote necessário não estiver disponível no cache ou no contexto correspondente, pode pedir confirmação para obtê-lo. Confira que o nome apresentado é o Angular CLI e que a versão corresponde ao comando. Depois confirme para continuar a demonstração.

CAIO: Por que não instalamos um comando ng global antes? Já vi tutoriais começarem com isso.

PROF. RODRIGO: A instalação global é outra forma de usar o CLI. Aqui estamos identificando a versão no comando que cria o projeto. Depois da criação, o próprio projeto terá suas ferramentas locais. Essa escolha torna a explicação da versão mais direta. O importante é entender qual ferramenta está sendo executada, especialmente quando você trabalha em projetos de épocas diferentes.

PROF. RODRIGO: A palavra new pede uma aplicação nova. Central traço solicitacoes é o nome da pasta e do projeto. Style igual a css escolhe CSS para os estilos. Routing igual a false deixa o roteamento fora deste começo. SSR igual a false deixa a renderização no servidor fora da geração inicial. Vamos aprender esses recursos quando houver uma necessidade para eles no curso.

MARINA: Prefix igual a cet usa a identificação Código em Tela nos seletores gerados. Skip git adia a inicialização do repositório nessa criação. Defaults aceita os valores padrão das outras opções que têm um padrão. O projeto desta versão usa componentes standalone. Não precisamos adicionar um módulo apenas porque um tutorial antigo mostrava um arquivo chamado app module.

CAIO: Essa linha ficou grande. Posso executar uma opção de cada vez, apertando Enter entre elas?

PROF. RODRIGO: Neste comando, as opções pertencem à mesma execução. Copie a linha inteira; o terminal pode quebrá-la visualmente porque a janela é estreita. O apêndice mantém a sequência completa para consulta. Durante a gravação, destacaremos cada opção, mas não vamos transformar uma quebra de exibição em vários comandos independentes.

PROF. RODRIGO: A criação tem duas atividades fáceis de confundir. Primeiro, o gerador escreve arquivos de configuração e código inicial. Depois, o gerenciador de pacotes instala as dependências. Ver nomes de arquivos aparecendo ainda não garante que a instalação terminou. Aguarde a conclusão e leia a última mensagem. Se a rede interromper a segunda etapa, a pasta pode existir e ainda faltar uma instalação completa.

MARINA: Também há dois tipos de versão aqui. O comando escolhe o gerador. Os pacotes do projeto são resolvidos a partir das declarações geradas, e o arquivo de lock registra o resultado. Guardar esse arquivo permite que outra instalação siga as versões registradas. Mais adiante vamos conferir tanto o CLI local quanto o Angular instalado.

DEMONSTRAÇÃO 30: Executar o comando e mostrar arquivos criados. Acelerar a espera de rede com indicação visual. No fim, mostrar a conclusão real e a pasta central-solicitacoes. Se aparecer pergunta adicional, registrar a resposta utilizada; não inventar uma tela de sucesso.

Fonte técnica: [Comando ng new](https://angular.dev/cli/new) e [Execução de pacotes com npm](https://docs.npmjs.com/cli/v11/commands/npm-exec/).

### 06 Abrir o projeto e iniciar o servidor

CENA: Rodrigo, Lia e Rafael. Entrar no diretório recém-criado, abrir a pasta no VS Code e executar o servidor. Mostrar o endereço exibido no terminal antes de ir ao navegador.

```shell
cd central-solicitacoes
code .
npm start
```

PROF. RODRIGO: Entramos na pasta central traço solicitacoes. Code espaço ponto pede ao VS Code para abrir a pasta atual. Se esse comando não estiver configurado no seu terminal, abra o editor pelo menu do sistema e use Abrir Pasta. O resultado que precisamos é a pasta do projeto aberta, com package ponto json visível na raiz.

LIA: Quando executei npm start, o terminal começou a trabalhar e não voltou para a linha em que posso digitar. Ele travou?

PROF. RODRIGO: Nesse caso, ele mantém um processo ativo: o servidor de desenvolvimento. O projeto gerado define start como uma forma de chamar o servidor do Angular. Quando estiver pronto, o terminal mostrará um endereço local. Abra esse endereço no navegador. Normalmente, sem outra aplicação ocupando a porta, será localhost com a porta quatro mil e duzentos.

```text
http://localhost:4200
```

RAFAEL: Localhost aponta para o próprio computador em que esse navegador está executando. Esse endereço ainda não é uma publicação do nosso site. Se eu enviar o texto localhost para outra pessoa, o navegador dela vai procurar o computador dela, não o meu servidor.

PROF. RODRIGO: Na aula 2, o exemplo usava a porta quatro mil duzentos e dois. Nesta criação, estamos usando o padrão quatro mil e duzentos. A porta identifica o serviço que o navegador vai acessar. Leia a resposta real do terminal: se você escolher outra porta, precisa abrir o endereço correspondente.

LIA: Como faço para parar sem fechar tudo?

PROF. RODRIGO: Volte ao terminal do servidor e pressione Control C. Se o terminal pedir confirmação para encerrar, responda conforme a mensagem. Para executar novamente, use npm start na pasta do projeto. Não é necessário criar outra aplicação. Os arquivos continuam salvos; o que você interrompeu foi o processo que estava servindo a página.

RAFAEL: Vamos observar a tela de boas-vindas antes de editar qualquer coisa. Isso estabelece uma referência: o projeto recém-criado conseguiu executar. Na próxima parte, quando mudarmos um arquivo, teremos um resultado anterior com o qual comparar. Esse hábito ajuda a localizar em qual etapa uma dificuldade apareceu.

DEMONSTRAÇÃO 25: Abrir a página inicial, parar o servidor, tentar uma nova conexão e reiniciá-lo. Explicar que uma aba já carregada pode continuar exibindo conteúdo mesmo com o servidor parado. Confirmar a nova conexão após reiniciar.

PROF. RODRIGO: O primeiro projeto está acessível. Agora vamos entender os arquivos que produziram essa tela e fazer uma alteração pequena, com resultado fácil de reconhecer.

Fonte técnica: [Servidor de desenvolvimento Angular](https://angular.dev/tools/cli/serve).

## Parte 3 Entender a estrutura

### 07 As pastas têm responsabilidades diferentes

CENA: Thumbnail por cinco segundos. Rodrigo, Caio e Marina diante do explorador de arquivos. Abrir somente os diretórios comentados. Não exibir a árvore inteira de node_modules.

PROF. RODRIGO: Já conseguimos executar a aplicação. Agora vamos construir um mapa de leitura. O projeto tem arquivos da nossa interface, configurações das ferramentas e dependências instaladas. Vamos identificar os principais para saber onde procurar quando precisarmos alterar alguma coisa. Não é necessário decorar todos os nomes de uma vez.

CAIO: A pasta node modules tem tanta coisa que parece maior do que todo o projeto. Nosso código fica misturado ali?

PROF. RODRIGO: Node modules guarda os pacotes instalados. Não vamos editar os arquivos dessa pasta para implementar a Central. As alterações da aplicação ficarão principalmente dentro de src. Pense em qual conteúdo é nosso código e qual conteúdo é uma dependência obtida pelo gerenciador. Essa distinção também ajuda a entender o que deve acompanhar um repositório do projeto.

MARINA: Package ponto json descreve informações do projeto, dependências e scripts. O script start que executamos está ali. O arquivo package traço lock ponto json registra a resolução das dependências. Eles trabalham juntos: um declara requisitos e tarefas; o outro ajuda a reproduzir a árvore instalada. Não são duas cópias com nomes diferentes.

PROF. RODRIGO: Angular ponto json contém a configuração do workspace e de tarefas como compilar e servir. Os arquivos tsconfig configuram a análise e a compilação de TypeScript. Hoje vamos reconhecê-los e deixar os valores gerados. Quando uma aula precisar de uma mudança de configuração, vamos explicar qual comportamento aquela alteração procura obter.

TELA: Mostrar a tabela do apêndice com apenas um grupo de arquivos por vez. Destacar src/app, src/main.ts, src/index.html, src/styles.css e public. Dist significa saída de compilação e pode ainda não existir antes do build.

CAIO: E a diferença entre public e src? Se eu colocar um texto em um arquivo dentro de public, ele vira um componente?

PROF. RODRIGO: A pasta public contém recursos estáticos que a configuração pode copiar para a aplicação servida, como uma imagem. Um arquivo ali não vira componente por estar nessa pasta. Em src teremos o código de entrada e os componentes. O lugar do arquivo faz parte da organização, mas são as configurações e as referências que explicam como ele participa da aplicação.

MARINA: Outra pasta que pode aparecer é dist, depois de uma compilação. Ela contém a saída gerada. Se você corrigir só um arquivo da saída e depois compilar novamente, a mudança pode desaparecer. Para alterar a Central, precisamos modificar a origem correspondente. O arquivo gerado ajuda a publicar ou inspecionar o resultado, mas não substitui o código-fonte.

PROF. RODRIGO: Faça uma associação concreta. Para descobrir o que npm start executa, procure os scripts de package ponto json. Para mudar o texto da página, vamos olhar o template do componente. Para uma regra de estilo da página, veremos seu CSS. Quando tiver uma dúvida, essa primeira classificação já reduz bastante a quantidade de arquivos que você precisa abrir.

PAUSA 12: Perguntar onde procurar os scripts, o template e as dependências instaladas. Revelar package.json, app.html e node_modules depois da pausa.

Fonte técnica: [Estrutura de arquivos do Angular](https://angular.dev/reference/configs/file-structure) e [Formato package.json](https://docs.npmjs.com/cli/v11/configuring-npm/package-json/).

### 08 Como o componente principal chega ao navegador

CENA: Rodrigo, Lia e Marina. Mostrar index.html, main.ts e app.ts em sequência, com uma única relação destacada por vez. Nesta geração, o seletor da raiz é cet-root.

PROF. RODRIGO: Vamos acompanhar a inicialização. Em src, abra index ponto html. Ele contém a estrutura inicial do documento, com elementos como head e body. No corpo, você encontrará cet traço root. Esse elemento corresponde ao seletor do componente principal gerado com o prefixo que escolhemos.

LIA: Então cet root é uma tag que o navegador já conhecia?

PROF. RODRIGO: É um elemento usado como ponto de montagem da nossa aplicação Angular. A configuração do componente informa o seletor correspondente. O navegador recebe também os arquivos JavaScript produzidos pelas ferramentas. Quando a inicialização do Angular acontece, ele cria a apresentação do componente nesse lugar.

```html
<cet-root></cet-root>
```

MARINA: Agora abra main ponto ts. Você verá a chamada de bootstrapApplication com o componente App e a configuração da aplicação. Bootstrap, nesse nome, está relacionado à inicialização. Não estamos falando da biblioteca de estilos que também se chama Bootstrap. Aqui a chamada inicia a aplicação Angular com a raiz indicada.

```typescript
import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { App } from './app/app';

bootstrapApplication(App, appConfig)
  .catch((err) => console.error(err));
```

PROF. RODRIGO: A configuração pode registrar recursos usados pela aplicação. Vamos preservá-la como o gerador a criou. Para esta aula, o ponto de leitura é identificar quem inicia a aplicação e qual componente foi escolhido. Não precisamos desmontar uma configuração funcional para chegar à primeira mudança de texto.

LIA: No exemplo da aula 2, o arquivo App estava direto em src e a raiz se chamava cet app. Agora aparece uma pasta app e o nome cet root. Isso muda o conceito?

PROF. RODRIGO: O conceito é o mesmo. A aula anterior usava um exemplo organizado para aquela demonstração. O CLI gerou agora sua estrutura convencional, com os arquivos dentro de src barra app e o seletor cet root. Os caminhos de importação e a referência no HTML precisam corresponder à organização real. Copiar um caminho antigo sem conferir a pasta atual pode quebrar essa ligação.

MARINA: Dentro de app ponto ts, procure templateUrl e styleUrl. Eles indicam o HTML e o CSS do componente, usando caminhos relativos a esse arquivo. É a mesma relação que estudamos no cartão. Na nomenclatura moderna, os nomes podem ser app ponto ts, app ponto html e app ponto css. Materiais antigos frequentemente incluem a palavra component no nome.

PROF. RODRIGO: Vamos percorrer o caminho mais uma vez pela intenção. O documento inicial oferece o ponto de montagem. O código de entrada inicia o Angular. A raiz escolhida indica seu template e seus estilos. Quando a página aparecer, saberemos quais arquivos abrir para entender seu conteúdo. Na próxima etapa, faremos uma mudança que confirma essa leitura.

DEMONSTRAÇÃO 20: Destacar cet-root em index.html e selector em app.ts. Depois destacar App em main.ts e templateUrl em app.ts. Deixar o navegador visível ao final.

Fonte técnica: [Inicialização com bootstrapApplication](https://angular.dev/api/platform-browser/bootstrapApplication) e [Anatomia dos componentes](https://angular.dev/guide/components).

### 09 A primeira alteração precisa ser pequena

CENA: Rodrigo, Bia e Rafael. Antes de editar, mostrar a tela de boas-vindas. Substituir o conteúdo de app.ts e app.html pelos arquivos mínimos abaixo. Limpar app.css e usar o CSS global indicado no apêndice quando chegarmos à parte 4.

PROF. RODRIGO: Vamos fazer uma alteração controlada. O template de boas-vindas pode ter bastante conteúdo. Para estudar a nossa página, vamos substituí-lo por um título e uma frase. Também deixaremos a classe inicial com uma configuração pequena e coerente com esse template. Assim, nenhum recurso que pertencia só à apresentação de boas-vindas ficará confundindo a leitura.

```typescript
import { Component } from '@angular/core';

@Component({
  selector: 'cet-root',
  standalone: true,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {}
```

```html
<main>
  <h1>Central de Solicitações Internas</h1>
  <p>Nosso projeto Angular está funcionando.</p>
</main>
```

BIA: Antes de acrescentar cores, vamos conferir o conteúdo. Temos um título principal que identifica a página e uma frase que permite reconhecer nossa alteração. Essa verificação é fácil de repetir: eu sei o que deveria aparecer e onde deveria aparecer.

PROF. RODRIGO: Em index ponto html, vamos ajustar lang para pt traço BR e o elemento title para Central de Solicitações Internas. Lang informa o idioma do documento, usado também por tecnologias assistivas. Title identifica a aba do navegador. O h um continua sendo o título dentro da página. Embora os textos possam coincidir, eles ocupam lugares diferentes e precisamos conferir os dois.

TELA: Alterar somente lang e title em src/index.html conforme o apêndice, preservando cet-root e as demais configurações geradas.

PROF. RODRIGO: Salve os arquivos e acompanhe o terminal. O servidor de desenvolvimento observa mudanças e prepara a atualização. Dependendo do tipo de alteração, a ferramenta pode atualizar parte da aplicação ou recarregar a página. O comportamento que queremos verificar agora é simples: a frase nova deve aparecer e a tela inicial deve dar lugar ao nosso conteúdo.

RAFAEL: Se não mudou, eu começo conferindo se o arquivo foi salvo, se o terminal continua com o servidor ativo e se o navegador está no endereço desse projeto. Quando estudamos com várias pastas abertas, é possível editar uma cópia e observar outra. Reescrever o título dez vezes não resolve essa troca de contexto.

BIA: Vou modificar a frase para Projeto da equipe Código em Tela e salvar. Depois volto para a frase anterior. Essa pequena ida e volta mostra que a tela acompanha o arquivo que estamos editando. É uma conferência útil antes de colocar uma quantidade maior de conteúdo.

PROF. RODRIGO: Há mais um arquivo para reconhecer: o teste gerado do componente, caso ele esteja presente. Ele pode verificar um texto da tela de boas-vindas. Como alteramos esse requisito, a expectativa precisa acompanhar a nova página. O apêndice fornece a atualização correspondente. O servidor de desenvolvimento não executa automaticamente toda a suíte de testes a cada alteração.

RAFAEL: Essa distinção evita uma conclusão apressada. Ver a página funcionando é uma evidência de que conseguimos executá-la. Ainda vamos conferir a compilação e os critérios do exercício. Cada verificação responde a uma pergunta específica. Não devemos usar a palavra pronto sem dizer qual comportamento foi observado.

PAUSA 10: Pedir ao aluno uma frase própria, salvar e conferir no navegador. Orientar a pausar o vídeo para executar. Depois restaurar a frase de referência para manter a continuidade dos próximos trechos.

PROF. RODRIGO: Já localizamos a origem do que vemos na página. Na próxima parte, vamos colocar dados na classe, construir a apresentação da Central e retomar uma interação com estado local.

Fonte técnica: [Desenvolvimento com ng serve](https://angular.dev/tools/cli/serve) e [Fundamentos de teste](https://angular.dev/guide/testing/components-basics).

## Parte 4 Construir a base da Central

### 10 Dar nomes aos dados da página

CENA: Thumbnail por cinco segundos. Helena, Rodrigo e Marina. Mostrar a página final desta parte durante oito segundos, antes de revelar o código. O registro fictício é SOL-1042, com o assunto Não consigo acessar o sistema.

HELENA: Agora que a equipe consegue abrir a aplicação, quero que a página se identifique como nossa Central. Ela deve mostrar o nome do produto, indicar que estamos em um ambiente de aprendizagem e apresentar um pedido de exemplo. Também quero um lugar para explicar como acompanhar esse pedido.

PROF. RODRIGO: Vamos preparar essa base mantendo o exemplo pequeno. A classe App terá propriedades para o título, a identificação do ambiente e os dados do pedido fictício. Na aula anterior, agrupamos informações de solicitações em objetos e trabalhamos com componentes filhos. Aqui vamos usar algumas propriedades simples para acompanhar a primeira edição de um projeto recém-gerado.

```typescript
readonly titulo = 'Central de Solicitações Internas';
readonly ambiente = 'Ambiente local de aprendizagem';
readonly protocolo = 'SOL-1042';
readonly assunto = 'Não consigo acessar o sistema';
```

MARINA: Readonly informa ao TypeScript que essa propriedade não deve ser reatribuída depois da inicialização da instância. Isso não cria, por si só, um estado reativo e não grava dados em lugar algum. Neste recorte, esses valores são fixos. O estado que muda com o botão será representado separadamente.

HELENA: O aluno pode trocar o título e o assunto para entender a ligação com a tela?

PROF. RODRIGO: Pode, e vamos fazer essa experiência. Depois de ligar as propriedades ao template, uma alteração no valor do título ficará visível na aplicação atualizada. Precisamos distinguir essa edição do código durante o desenvolvimento de uma pessoa preenchendo um formulário. Ainda não criamos um campo para cadastrar pedidos nem uma comunicação com uma API.

MARINA: Também vamos preservar o significado do protocolo. SOL traço mil e quarenta e dois identifica o registro fictício exibido na interface. Os cards SOL 01 e SOL 02 continuam sendo itens do trabalho da equipe. Não vamos usar a aparência parecida desses nomes para sugerir que um é automaticamente o registro do outro.

PROF. RODRIGO: Abra app ponto ts e acrescente essas propriedades dentro da classe. O decorador continua apontando para os mesmos arquivos. Esse é um bom momento para conferir os limites: a configuração do componente fica no objeto de Component; os dados e métodos da instância ficam no corpo da classe. Colocar uma propriedade da página dentro da configuração errada produz outro significado ou um erro.

HELENA: Então a organização já nos ajuda a explicar o que estamos entregando. Temos uma página que apresenta um exemplo conhecido e uma indicação clara do ambiente em que ele está sendo mostrado.

PROF. RODRIGO: Sim. Vamos ligar esses valores à apresentação e observar o resultado antes de acrescentar o botão. Esse avanço por pequenas etapas deixa mais claro qual mudança provocou cada comportamento.

DEMONSTRAÇÃO 15: Acrescentar as quatro propriedades, uma por vez. Destacar o interior da classe e preservar o decorador. Ainda não mostrar a implementação da interação.

### 11 O template apresenta e o CSS organiza

CENA: Rodrigo, Lia e Bia. Mostrar primeiro a página esperada, depois o trecho de template. O HTML completo da versão final está no apêndice. Construir cabeçalho e seção do pedido antes de inserir o botão.

```html
<main class="pagina">
  <header class="cabecalho">
    <p class="marca">Código em Tela</p>
    <h1>{{ titulo }}</h1>
    <p>{{ ambiente }}</p>
  </header>

  <section class="painel" aria-labelledby="titulo-pedido">
    <h2 id="titulo-pedido">Solicitação de exemplo</h2>
    <p class="protocolo">{{ protocolo }}</p>
    <p>{{ assunto }}</p>
    <p><strong>Status:</strong> Aberta</p>
  </section>
</main>
```

LIA: O título agora está entre duas chaves de cada lado. Na primeira alteração, escrevemos o texto diretamente dentro do h um. O que muda?

PROF. RODRIGO: As chaves indicam uma interpolação. O Angular avalia a expressão e apresenta seu valor como texto naquele lugar. Aqui, titulo é uma propriedade da classe. Não colocamos parênteses porque ela é uma string comum. Quando lermos um signal, veremos a chamada com parênteses, como já aconteceu na aula anterior.

BIA: O HTML também expressa a organização da página. Main identifica o conteúdo principal, header reúne a apresentação e a seção do pedido possui um título. A cor e a borda ajudam visualmente, mas os nomes e a estrutura continuam transmitindo informação. O status aparece por escrito, sem depender de uma cor para ser compreendido.

PROF. RODRIGO: Salve e confira os quatro valores. Depois troque temporariamente o assunto na classe. O template continua com a mesma expressão, mas o texto apresentado vem do novo valor. Essa relação será usada quando os dados deixarem de ser constantes de demonstração e passarem a chegar de outras partes da aplicação.

LIA: E as classes pagina, cabecalho e painel? São classes de TypeScript também?

PROF. RODRIGO: Aqui são nomes de classes CSS no HTML. Eles permitem selecionar elementos para aplicar estilos. A palavra classe aparece em contextos diferentes. App é uma classe TypeScript; painel, neste atributo do template, é um nome que usaremos no CSS. O contexto e a sintaxe ajudam a reconhecer qual significado está em jogo.

BIA: No CSS do componente, vamos limitar a largura do conteúdo, centralizar a página e usar espaçamento interno no painel. Também permitiremos que títulos grandes quebrem de linha. Um texto real nem sempre tem o tamanho da primeira frase de exemplo. A página precisa continuar legível quando a janela fica menor.

PROF. RODRIGO: O CSS global ficará em styles ponto css, com a fonte geral, a margem do body e o cálculo de tamanho dos elementos. O CSS de App tratará a apresentação desta página. Os estilos do componente usam o encapsulamento padrão do Angular para limitar seu alcance, mas regras globais e propriedades herdadas continuam podendo influenciar o resultado.

BIA: Vou reduzir a janela e conferir o título, o protocolo e o painel. Se uma linha ficar comprida, ajustamos a quebra e o espaçamento. Não vamos diminuir tudo até o texto ficar ilegível. Na próxima etapa, o botão também precisa ter área de clique confortável e foco visível para quem usa teclado.

DEMONSTRAÇÃO 25: Aplicar o CSS completo do apêndice, editar e restaurar o assunto, comparar a página larga e estreita. Abrir app.css e styles.css em momentos separados. Evitar código minúsculo para mostrar os dois ao mesmo tempo.

Fonte técnica: [Interpolação e ligação de propriedades](https://angular.dev/guide/templates/binding) e [Estilos de componentes](https://angular.dev/guide/components/styling).

### 12 Retomar eventos e estado local

CENA: Rodrigo, Caio e Bia. Mostrar o botão funcionando antes do código. A seção de orientações começa oculta, abre no primeiro acionamento e fecha no segundo. Não alterar o status Aberta do pedido.

CAIO: A página já mostra os dados. Para abrir as orientações, vamos procurar o elemento no documento e trocar seu estilo manualmente?

PROF. RODRIGO: Vamos representar a escolha no estado do componente e deixar o template descrever o que deve aparecer. Usaremos um signal booleano, começando em false. Seu nome será mostrarOrientacoes. O método alternarOrientacoes inverterá esse valor quando o botão for acionado. É a mesma ideia de acompanhar estado e apresentação que estudamos na expansão do cartão.

```typescript
import { Component, signal } from '@angular/core';

// Dentro da classe App:
readonly mostrarOrientacoes = signal(false);

alternarOrientacoes(): void {
  this.mostrarOrientacoes.update((valor) => !valor);
}
```

CAIO: O readonly não impede o signal de mudar? Acabamos de dizer que a propriedade não deve ser reatribuída.

PROF. RODRIGO: Ele impede reatribuir a propriedade a outro signal. O valor mantido pelo signal pode ser atualizado pela API dele. Na função passada a update, valor representa o booleano atual. A exclamação produz sua negação: false passa a true e true passa a false. Estamos alternando uma decisão com dois estados possíveis.

```html
<button type="button"
  [attr.aria-expanded]="mostrarOrientacoes()"
  (click)="alternarOrientacoes()">
  {{ mostrarOrientacoes()
    ? 'Ocultar orientações'
    : 'Mostrar orientações' }}
</button>

@if (mostrarOrientacoes()) {
  <div class="orientacoes">
    <h3>Como acompanhar o pedido</h3>
    <p>Guarde o protocolo e consulte o andamento na Central.</p>
    <p>Este exemplo usa dados fictícios e estado local.</p>
  </div>
}
```

BIA: O texto do botão acompanha o que a ação fará. Quando as orientações estão ocultas, ele oferece mostrar. Quando estão visíveis, oferece ocultar. O atributo aria expanded também acompanha o estado de expansão. Além de olhar a tela, vamos usar Tab para chegar ao botão e Enter para acioná-lo.

PROF. RODRIGO: Os parênteses em click ligam o evento à chamada do método. O bloco arroba if inclui o conteúdo quando a condição é verdadeira. As leituras de mostrarOrientacoes têm parênteses porque estamos lendo o signal. O botão, o atributo e o bloco consultam a mesma origem. Isso reduz a chance de um texto anunciar aberto enquanto o conteúdo continua fechado.

CAIO: E se eu usar só mostrarOrientacoes, sem chamar? Parece um detalhe pequeno.

PROF. RODRIGO: Você estará referenciando o signal em vez de obter seu valor booleano. Precisamos escrever a leitura adequada ao tipo de dado usado. Essa diferença é uma boa razão para conferir as mensagens do editor e do compilador, em vez de avaliar o código somente pela aparência parecida dos nomes.

BIA: Vou abrir e fechar, conferir o foco e reduzir a largura da janela. Também observo se o botão continua dentro do painel e se o texto das orientações quebra normalmente. Esses são comportamentos que podemos demonstrar agora. Depois de recarregar a página, vamos conferir o estado inicial novamente.

PROF. RODRIGO: Ao recarregar, a nova instância começa com false e as orientações voltam a ficar ocultas. Não implementamos persistência. O status do atendimento permanece Aberta durante os cliques, porque mostrar orientação não é concluir um pedido. Na próxima parte, vamos investigar um erro pequeno, praticar uma mudança e compilar a versão final.

DEMONSTRAÇÃO 30: Abrir, fechar, usar Tab e Enter, recarregar e confirmar o estado inicial. Mostrar o caminho evento, método, estado e apresentação sem colocar mais de um trecho de código em destaque ao mesmo tempo.

Fonte técnica: [Signals](https://angular.dev/guide/signals), [Eventos no template](https://angular.dev/guide/templates/event-listeners) e [Controle de fluxo](https://angular.dev/guide/templates/control-flow).

## Parte 5 Investigar e verificar

### 13 Ler o erro antes de mudar a solução

CENA: Thumbnail por cinco segundos. Rodrigo, Lia e Rafael. Partir da aplicação funcionando. Criar deliberadamente um erro de nome no template e identificar a experiência como demonstração de diagnóstico. Corrigir antes de continuar.

PROF. RODRIGO: Nossa página já apresenta o pedido e responde ao botão. Agora vamos praticar uma habilidade que acompanha todo o desenvolvimento: descobrir o que uma mensagem está dizendo. Vou trocar temporariamente titulo por tituloPagina no template, sem criar essa propriedade na classe. Observe a resposta das ferramentas antes de tentar corrigir.

```html
<h1>{{ tituloPagina }}</h1>
```

LIA: O nome parece fazer sentido em português, mas o projeto não conhece essa propriedade. É por isso que aparece uma mensagem apontando o template?

RAFAEL: Sim. Leia o nome citado, o arquivo e a posição indicada. A mensagem exata pode variar entre versões, mas precisamos reconhecer a incompatibilidade: o template pede uma propriedade que não existe naquele componente. Vamos comparar o nome usado com o declarado na classe. A correção desta experiência é voltar para titulo.

PROF. RODRIGO: Salve novamente e observe se o erro desaparece. Essa sequência mostra como reduzir a investigação. Sabemos qual alteração fizemos, qual resultado esperávamos e qual mensagem apareceu. Se mudássemos cinco arquivos sem verificar entre eles, teríamos mais possibilidades para investigar.

LIA: E quando o erro acontece antes de abrir a aplicação? Por exemplo, o npm diz que não encontrou package ponto json.

RAFAEL: Primeiro confira a pasta atual. O comando precisa executar no projeto que contém esse arquivo. Depois observe se a criação realmente terminou. Uma pasta existente não garante que todas as etapas foram concluídas. Se os arquivos foram gerados, mas a instalação de pacotes falhou por interrupção da rede, podemos entrar no projeto e retomar npm install depois de resolver a conexão.

PROF. RODRIGO: Outro caso comum é a porta ocupada. Talvez um servidor anterior ainda esteja ativo. Você pode voltar àquele terminal e encerrá-lo, se for o servidor desta atividade, ou escolher outra porta para a nova execução. O script start aceita que encaminhemos uma opção usando dois hífens como separador.

```shell
npm start -- --port 4201
```

RAFAEL: Nesse caso, abra o endereço com a porta quatro mil duzentos e um que o terminal mostrar. Não encerre um processo desconhecido apenas para liberar um número. Também não confunda uma página antiga que permaneceu carregada com a confirmação de que o servidor novo está ativo. Faça uma nova conexão ao endereço correto.

LIA: Quando recebo várias mensagens juntas, posso mandar só a última linha dizendo que deu erro?

PROF. RODRIGO: Para pedir ajuda, informe o comando, a pasta do projeto, as versões de Node e Angular e o trecho relevante da mensagem. Diga o resultado que esperava e o que aconteceu. Evite incluir senhas ou informações de outros projetos em uma captura. Essas informações objetivas permitem reproduzir a situação e ajudam você a organizar o próprio raciocínio.

PAUSA 15: Apresentar três sintomas: propriedade inexistente, package.json não encontrado e porta ocupada. Pedir uma primeira conferência para cada um. Depois destacar nome declarado, pasta atual e servidor/endereço.

Fonte técnica: [Checagem de templates](https://angular.dev/tools/cli/template-typecheck), [Opções de ng serve](https://angular.dev/cli/serve) e [Scripts npm](https://docs.npmjs.com/cli/v11/using-npm/scripts/).

### 14 Um exercício para fazer e explicar

CENA: Helena, Wellington e Rodrigo. Exibir somente a demanda e os critérios antes da pausa. A solução deve permanecer fora do enquadramento e da legenda até o momento indicado.

HELENA: Quero acrescentar à página o nome da equipe responsável pelo acompanhamento. Nesta versão, a informação será Equipe de suporte interno. Ela deve aparecer abaixo da identificação do ambiente, antes do painel do pedido. Quando esse nome mudar no código, a página precisa usar o novo valor sem repetir o texto manualmente em outro lugar.

WELLINGTON: Vou registrar os critérios. Criar um dado para o nome da equipe, apresentá-lo no cabeçalho, manter a interação das orientações funcionando e conferir a página em uma janela estreita. Também quero uma explicação curta indicando os arquivos alterados. Essa prática compõe o aprendizado da sprint; a entrega consolidada continua no momento de revisão combinado.

PROF. RODRIGO: Antes de escrever, diga onde o dado ficará e como o template vai acessá-lo. Em seguida, implemente e confira. Use um nome de propriedade que consiga reconhecer, como equipeResponsavel. Não é necessário criar um formulário nem cadastrar a equipe em um servidor. A demanda desta prática é apresentar uma informação local com uma origem clara.

PAUSA 25: Mostrar a instrução Pause o vídeo para implementar. Manter a demanda e os quatro critérios legíveis. O aluno dispõe do tempo de estudo que precisar; os 25 segundos são apenas a pausa editorial antes da resposta.

PROF. RODRIGO: Vamos comentar uma solução. Dentro da classe App, acrescento uma propriedade readonly chamada equipeResponsavel, com o nome da equipe. No cabeçalho do template, depois da identificação do ambiente, acrescento um parágrafo que lê essa propriedade por interpolação. Como estamos usando uma string, a leitura não tem os parênteses de um signal.

```typescript
readonly equipeResponsavel = 'Equipe de suporte interno';
```

```html
<p>Responsável pelo acompanhamento: {{ equipeResponsavel }}</p>
```

CENA: Rafael e Bia entram para a verificação, com Rodrigo. Helena e Wellington saem do destaque. Mostrar a alteração no navegador antes de comentar a checagem.

RAFAEL: Primeiro confiro o texto abaixo da identificação do ambiente. Depois troco temporariamente o valor da propriedade para Equipe de atendimento e salvo. A apresentação precisa acompanhar a mudança. Por fim, restauro o nome de referência. Essa experiência ajuda a detectar o caso em que alguém escreveu o nome diretamente no HTML e deixou a propriedade sem uso.

BIA: Vou usar um nome maior, Equipe de suporte aos sistemas internos, e reduzir a largura da janela. O texto precisa quebrar sem invadir o painel e sem desaparecer. Também uso Tab para chegar ao botão, abro as orientações e fecho novamente. Acrescentar um parágrafo não deveria impedir a interação que já existia.

PROF. RODRIGO: Repare na sequência: tivemos uma necessidade, escolhemos onde manter a informação, ligamos a apresentação ao dado e conferimos o resultado. Se você usou outro nome de propriedade, compare a coerência entre a declaração e o template. O objetivo do exercício é explicar essa relação e demonstrar os critérios, não reproduzir uma palavra sem entender seu uso.

RAFAEL: Agora recarrego a página e confiro o início com as orientações ocultas. O nome da equipe continua porque está no código da aplicação. A expansão volta ao valor inicial porque era estado temporário daquela instância. São dois resultados diferentes, e ambos estão de acordo com o que implementamos.

PROF. RODRIGO: Anote o que você mudou em app ponto ts e em app ponto html. Se ajustou o visual, registre também o CSS. Essa pequena explicação vai ajudar quando retomarmos o projeto e quando outra pessoa precisar reproduzir sua versão. O código final do apêndice preserva o ponto anterior ao exercício, e a solução aparece separada logo depois.

DEMONSTRAÇÃO 20: Conferir a solução com o nome padrão, nome alternativo e janela estreita. Restaurar a versão anterior ao exercício no projeto principal; manter a solução em uma cópia ou alteração identificada.

### 15 Compilar e saber retomar o trabalho

CENA: Rodrigo, Rafael e Wellington. Abrir um segundo terminal na raiz do projeto ou parar o servidor atual antes de compilar. Mostrar o comando, aguardar a conclusão real e depois voltar à página.

```shell
npm run build
```

PROF. RODRIGO: Vamos executar o script build. Ele chama a compilação definida pelo projeto e prepara a saída conforme a configuração usada. Uma compilação concluída ajuda a identificar problemas de código, referências e templates. Ela não publica automaticamente a aplicação na internet e não prova, sozinha, que todos os critérios de uso foram atendidos.

RAFAEL: Por isso já fizemos conferências no navegador. O título precisa estar correto, o protocolo deve corresponder ao exemplo, as orientações abrem e fecham e o estado inicial reaparece depois de recarregar. O build acrescenta outra evidência: a versão que estamos guardando também conseguiu passar pela compilação configurada.

WELLINGTON: Na preparação do ambiente, podemos marcar os critérios que demonstramos. Consultamos versões, geramos o projeto, executamos e reproduzimos uma alteração. Na prática da interface, mostramos os dados locais e a interação. As funcionalidades integradas continuam no planejamento da formação; o quadro precisa representar esse alcance.

PROF. RODRIGO: Se o teste inicial foi gerado, atualize a expectativa para o título da Central conforme o apêndice. O professor pode demonstrar npm test com a opção de não ficar observando alterações. A escrita de testes automatizados continua opcional para a entrega do aluno nesta etapa. Hoje quero que todos consigam executar e descrever as verificações da página.

```shell
npm test -- --watch=false
```

RAFAEL: Também vamos registrar o ambiente. Node versão, npm versão e a listagem de Angular core e Angular CLI identificam as ferramentas usadas. Isso é mais preciso do que anotar só Angular instalado. Se o projeto gerar versões diferentes das mostradas no vídeo, o arquivo de lock e essa listagem ajudam a entender a diferença.

```shell
npm ls @angular/core @angular/cli
```

PROF. RODRIGO: Para retomar amanhã, abra a pasta central traço solicitacoes e execute npm start. Se as dependências continuam instaladas, não é necessário baixar tudo novamente. Ao receber uma cópia do projeto com package ponto json e o lock correspondente, npm ci instala seguindo esse registro. Ele substitui a pasta de dependências existente e exige coerência entre os dois arquivos.

RAFAEL: Se os arquivos de declaração e lock estiverem divergentes, npm ci encerra com erro. Leia a mensagem e investigue a mudança. Atualizar dependências é uma decisão diferente de apenas reproduzir a instalação registrada. Para criar nosso projeto hoje, o próprio gerador já executou a instalação inicial.

WELLINGTON: Guarde seu código e uma breve instrução de execução no repositório da sua atividade, conforme a proposta da formação. Não publique a pasta node modules nem dados pessoais de outras atividades. A entrega consolidada continua sendo feita por sprint. Quando trouxer uma dúvida, indique a parte, o minuto e o comportamento observado.

PROF. RODRIGO: Hoje você preparou as ferramentas, criou um projeto e acompanhou como a raiz da aplicação chega ao navegador. Depois fez uma alteração pequena, apresentou dados da Central e retomou eventos e estado local. Você também praticou a leitura de erros, resolveu uma demanda e compilou o resultado. Esse conjunto permite continuar a formação trabalhando no seu próprio ambiente.

PROF. RODRIGO: Antes de encerrar, faça uma última experiência por conta própria: feche o servidor, reencontre a pasta e abra a aplicação novamente. Explique onde está o título e qual estado muda com o botão. O canal e a organização do Código em Tela estão na tela final. Continue com seu exercício e nos encontramos na próxima aula.

DEMONSTRAÇÃO 15: Exibir a compilação concluída e os critérios observados, somente após a execução correspondente. Encerrar com seis segundos para youtube.com/@codigoemtela e github.com/codigoemtela. Preservar margens e não sobrepor os links aos personagens. Identificar personagens e vozes gerados por IA na publicação; identificar também qualquer tela simulada efetivamente utilizada.

Fonte técnica: [Compilação com Angular CLI](https://angular.dev/cli/build), [Testes Angular](https://angular.dev/guide/testing) e [Instalação com npm ci](https://docs.npmjs.com/cli/v11/commands/npm-ci/).

## Apêndice de comandos e arquivos

Este apêndice reúne o ponto final da demonstração principal, antes do exercício da equipe responsável. Os trechos menores do roteiro representam etapas e não devem ser concatenados sem considerar as substituições indicadas. Os caminhos abaixo são relativos à pasta central-solicitacoes criada pelo CLI.

### Sequência principal de comandos

Executar na pasta de estudos. Se codigoemtela já existir, entrar nela. O comando npx é uma única linha, mesmo que apareça quebrado pela largura da página. Confirmar a obtenção de @angular/cli@22.1.6 quando solicitado. No Windows, se o PowerShell bloquear npm.ps1 ou npx.ps1, usar npm.cmd ou npx.cmd, respectivamente, ou o perfil Prompt de Comando do terminal.

```shell
node --version
npm --version
mkdir codigoemtela
cd codigoemtela
npx @angular/cli@22.1.6 new central-solicitacoes --style=css --routing=false --ssr=false --prefix=cet --skip-git --defaults
cd central-solicitacoes
code .
npm start
```

Para compilar ou conferir as versões, usar outro terminal na mesma pasta ou interromper o servidor com Ctrl+C antes dos comandos. Não executar ng new dentro da aplicação já criada para retomá-la.

```shell
npm run build
npm ls @angular/core @angular/cli
npm test -- --watch=false
```

### Alternativa Linux com o binário oficial do Node

No site oficial, selecionar a linha Node 24 LTS, Linux e a arquitetura do computador, e baixar o arquivo binário correspondente. Para o exemplo x64 consultado, o arquivo é node-v24.21.0-linux-x64.tar.xz. Em computadores ARM64, selecionar o arquivo correspondente e usar seu nome real. Extrair pelo gerenciador de arquivos dentro de uma pasta ferramentas criada na pasta pessoal. A pasta resultante contém bin/node, bin/npm e bin/npx. Não usar um pacote de arquitetura diferente.

Em Bash, para a sessão atual, usando a pasta e a versão do exemplo:

```shell
export PATH="$HOME/ferramentas/node-v24.21.0-linux-x64/bin:$PATH"
node --version
npm --version
```

O ajuste acima vale para essa sessão Bash. Para manter a configuração em terminais Bash interativos novos, acrescentar a mesma linha export ao arquivo ~/.bashrc usando o editor, uma única vez, e abrir outro terminal. Não substituir o conteúdo já existente. Se já usa um gerenciador de versões de Node, selecionar a linha compatível por ele em vez de misturar este caminho manual.

Em fish, usando a mesma pasta de exemplo, registrar o diretório com o comando próprio do shell:

```shell
fish_add_path "$HOME/ferramentas/node-v24.21.0-linux-x64/bin"
node --version
npm --version
```

Se a extração ocorreu em outra pasta, substituir o caminho pelo local real. Esses comandos adicionam uma localização de executáveis; não instalam um arquivo que ainda não foi baixado e extraído. A etapa comum seguinte é a conferência de versões. Fonte: [Download do Node](https://nodejs.org/en/download) e [fish_add_path](https://fishshell.com/docs/current/cmds/fish_add_path.html).

### Mapa de arquivos

| Caminho | Função nesta aula |
| --- | --- |
| package.json | Scripts e dependências declaradas |
| package-lock.json | Resolução registrada das dependências |
| angular.json | Configuração do workspace e das tarefas |
| tsconfig.json e derivados | Configuração de TypeScript |
| src/index.html | Documento inicial e elemento cet-root |
| src/main.ts | Inicialização com App e appConfig |
| src/app/app.config.ts | Configuração da aplicação gerada pelo CLI |
| src/app/app.ts | Classe, configuração e estado da página |
| src/app/app.html | Template da página |
| src/app/app.css | Estilos do componente principal |
| src/app/app.spec.ts | Teste do componente quando gerado |
| src/styles.css | Estilos globais |
| public | Recursos estáticos |
| node_modules | Dependências instaladas |
| dist | Saída criada pela compilação |

### Arquivo app ts

Caminho: src/app/app.ts. Substituir o conteúdo pelo arquivo completo abaixo.

```typescript
// SPDX-License-Identifier: GPL-3.0-only
import { Component, signal } from '@angular/core';

@Component({
  selector: 'cet-root',
  standalone: true,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  readonly titulo = 'Central de Solicitações Internas';
  readonly ambiente = 'Ambiente local de aprendizagem';
  readonly protocolo = 'SOL-1042';
  readonly assunto = 'Não consigo acessar o sistema';
  readonly mostrarOrientacoes = signal(false);

  alternarOrientacoes(): void {
    this.mostrarOrientacoes.update((valor) => !valor);
  }
}
```

### Ajustes em index html

Caminho: src/index.html. No documento gerado, alterar o atributo lang do elemento html para pt-BR e o conteúdo de title para Central de Solicitações Internas. Preservar base, viewport, favicon e cet-root. As linhas correspondentes devem ficar assim:

```html
<html lang="pt-BR">
<title>Central de Solicitações Internas</title>
```

Essas duas linhas pertencem a posições diferentes do documento: title permanece dentro de head. Não substituir o arquivo inteiro por esse trecho.

### Arquivo app html

Caminho: src/app/app.html. Substituir o conteúdo pelo arquivo completo abaixo.

```html
<main class="pagina">
  <header class="cabecalho">
    <p class="marca">Código em Tela</p>
    <h1>{{ titulo }}</h1>
    <p>{{ ambiente }}</p>
  </header>

  <section class="painel" aria-labelledby="titulo-pedido">
    <h2 id="titulo-pedido">Solicitação de exemplo</h2>
    <p class="protocolo">{{ protocolo }}</p>
    <p>{{ assunto }}</p>
    <p><strong>Status:</strong> Aberta</p>

    <button type="button"
      [attr.aria-expanded]="mostrarOrientacoes()"
      (click)="alternarOrientacoes()">
      {{ mostrarOrientacoes()
        ? 'Ocultar orientações'
        : 'Mostrar orientações' }}
    </button>

    @if (mostrarOrientacoes()) {
      <div class="orientacoes">
        <h3>Como acompanhar o pedido</h3>
        <p>Guarde o protocolo e consulte o andamento na Central.</p>
        <p>Este exemplo usa dados fictícios e estado local.</p>
      </div>
    }
  </section>
</main>
```

### Arquivo app css

Caminho: src/app/app.css. Substituir o conteúdo pelo arquivo completo abaixo.

```css
:host {
  display: block;
}

.pagina {
  max-width: 64rem;
  margin: 0 auto;
  padding: 2rem 1rem;
}

.cabecalho {
  margin-bottom: 1.5rem;
}

.marca {
  color: #5b21b6;
  font-weight: 700;
}

h1 {
  font-size: clamp(1.8rem, 4vw, 2.7rem);
  line-height: 1.15;
  overflow-wrap: anywhere;
}

.painel {
  padding: 1.5rem;
  background: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 0.75rem;
}

.protocolo {
  color: #475569;
  font-weight: 700;
}

button {
  padding: 0.8rem 1rem;
  max-width: 100%;
  border: 0;
  border-radius: 0.5rem;
  background: #5b21b6;
  color: #ffffff;
  cursor: pointer;
}

button:focus-visible {
  outline: 3px solid #0f172a;
  outline-offset: 3px;
}

.orientacoes {
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid #cbd5e1;
}
```

### Arquivo styles css

Caminho: src/styles.css. Substituir o conteúdo pelo arquivo completo abaixo.

```css
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  background: #f1f5f9;
  color: #0f172a;
  font-family: Arial, Helvetica, sans-serif;
  line-height: 1.6;
}

button {
  font: inherit;
}

p {
  overflow-wrap: anywhere;
}
```

### Teste do título atualizado

Caminho: src/app/app.spec.ts, quando o arquivo tiver sido gerado. Esta atualização acompanha a mudança da tela de boas-vindas para o título do produto. O professor pode demonstrá-la; não acrescenta uma exigência de teste automatizado à entrega do aluno.

```typescript
// SPDX-License-Identifier: GPL-3.0-only
import { TestBed } from '@angular/core/testing';
import { App } from './app';

describe('App', () => {
  it('apresenta o nome da Central', async () => {
    await TestBed.configureTestingModule({
      imports: [App]
    }).compileComponents();

    const fixture = TestBed.createComponent(App);
    await fixture.whenStable();
    const elemento = fixture.nativeElement as HTMLElement;

    expect(elemento.querySelector('h1')?.textContent)
      .toContain('Central de Solicitações Internas');
  });
});
```

### Solução separada do exercício

Manter o código anterior como ponto de partida. Para resolver o exercício, acrescentar a propriedade abaixo dentro de App em src/app/app.ts:

```typescript
readonly equipeResponsavel = 'Equipe de suporte interno';
```

Em src/app/app.html, imediatamente após o parágrafo que apresenta ambiente, acrescentar:

```html
<p>Responsável pelo acompanhamento: {{ equipeResponsavel }}</p>
```

Conferir o texto, trocar temporariamente o valor na classe, restaurá-lo, reduzir a largura da janela e verificar abrir, fechar e recarregar. Os arquivos de estilos da versão principal já permitem quebra de linha no novo parágrafo. Nenhum dado do pedido ou do botão precisa ser alterado para atender a essa demanda.

### Conferência antes de gravar

Executar a sequência em uma pasta nova e confirmar as opções do CLI. Registrar Node, npm, Angular e CLI efetivamente usados. Conferir cet-root e os caminhos de importação na estrutura gerada. Validar a versão inicial, a versão final e a solução do exercício. Confirmar build e, se mostrado no vídeo, o teste do título. Usar o terminal real para as mensagens de sucesso e de erro.

Medir a narração de cada parte e acrescentar as pausas realmente utilizadas. Cada arquivo publicado deve ficar abaixo de 15 minutos, contando cinco segundos de thumbnail, recapitulação e seis segundos de encerramento. Se uma parte ultrapassar a margem, dividir em um ponto de conclusão de seção e reescrever a transição. Atualizar capítulos e legendas depois da montagem. Não anunciar duração final antes de medi-la.

### Créditos do material

Roteiro e diálogos originais para Código em Tela, de Rodrigo Brito. Código original sob GPLv3, mantendo a convenção das aulas anteriores. Materiais originais sob CC BY 4.0, com atribuição a Código em Tela e Rodrigo Brito. Dependências e documentação de terceiros mantêm suas respectivas licenças. As referências técnicas aparecem junto aos assuntos correspondentes e servem à revisão e à preparação da gravação.

[Canal Código em Tela](https://www.youtube.com/@codigoemtela) e [GitHub Código em Tela](https://github.com/codigoemtela).
