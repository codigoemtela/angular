# Aula 3 — Ambiente e primeiro projeto Angular

Cinco vídeos finalizados, total de 56min47s.
Todas as partes ficam abaixo de 15 minutos. A capa ocupa os primeiros cinco
segundos de cada vídeo. As falas aprovadas foram preservadas.

## Arquivos de apoio

- capas/: cinco PNGs correspondentes aos quadros iniciais dos vídeos.
- legendas/: arquivos SRT em português, também incorporados aos MP4.
- capitulos/: marcações de capítulos por vídeo.
- materiais/projeto-principal/: exemplo antes do exercício.
- materiais/solucao-exercicio/: propriedade da equipe no cabeçalho.
- materiais/Roteiro_Aula_03_Com_Apendice.md: roteiro e código completo.
- Aula_03_Titulos_e_Descricoes.txt: textos prontos para a publicação.

## Executar o projeto

Abra uma das pastas do projeto. Use Node 24 compatível com Angular 22
(mínimo 24.15.0 na linha 24). Execute `npm ci` e depois `npm start`.
Abra o endereço informado pelo terminal. Encerre com Ctrl+C.
Para compilar, execute `npm run build`. O teste gerado pode ser executado com
`npm test -- --watch=false`.

`npm ci` exige package.json e package-lock.json coerentes e substitui a pasta
node_modules. Nenhuma dependência instalada está incluída neste pacote.

As orientações começam ocultas, abrem e fecham pelo botão e reiniciam ocultas
após recarregar. O status do pedido permanece Aberta. O projeto não usa API
nesta etapa. O exercício acrescenta equipeResponsavel abaixo do ambiente.

## Verificações

O projeto principal e a solução passaram pela compilação na revisão do roteiro.
O teste gerado e a alternância em teste DOM foram conferidos. Nos vídeos,
foram verificados texto completo, sincronização, limites das legendas,
decodificação, duração, resolução e permanência da capa.

Personagens e vozes gerados por IA. As telas da aplicação e dos comandos incluem representações didáticas simuladas, identificadas no vídeo.

Código original GPL-3.0-only; materiais didáticos CC BY 4.0.
Dependências mantêm suas próprias licenças.

https://youtube.com/@codigoemtela
https://github.com/codigoemtela
